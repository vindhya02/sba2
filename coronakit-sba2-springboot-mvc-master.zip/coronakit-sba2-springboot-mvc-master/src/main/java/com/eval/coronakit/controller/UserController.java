package com.eval.coronakit.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.eval.coronakit.entity.CoronaKit;
import com.eval.coronakit.entity.KitDetail;
import com.eval.coronakit.entity.ProductMaster;
import com.eval.coronakit.entity.User;
import com.eval.coronakit.service.CoronaKitService;
import com.eval.coronakit.service.KitDetailService;
import com.eval.coronakit.service.ProductService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	ProductService productService;
	
	@Autowired
	CoronaKitService coronaKitService;
	
	@Autowired
	KitDetailService kitDetailService;
	

	
	@RequestMapping("/home")
	public String home() {
		return "user-home";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(@ModelAttribute("userDetails") @Valid User userDetails,BindingResult result){
		ModelAndView mv = new ModelAndView("register","user",new User());
		mv.addObject("isNew",true);				
		return mv;
	}
	
	@RequestMapping("/show-kit")
	public ModelAndView showKit(Model model) {
		
		
		return new ModelAndView("show-cart","cart",kitDetailService.getAllKitItemsOfAKit());
	}

	@RequestMapping("/show-list")
	public String showList(Model model) {

		model.addAttribute("kitList", productService.getAllProducts());
		return "show-all-item-user";
	}
	
	@RequestMapping("/add-to-cart")
	public String showKit(@RequestParam("quantity") int quantity, @RequestParam("id") int id, @RequestParam("amount") int cost,Model model)  {

		KitDetail item = new KitDetail();
				
		item.setId(id);
		
		item.setQuantity(quantity);
		
		
		int amount = cost*quantity;
		item.setAmount(amount);
		
		if(item!=null)
		{
			kitDetailService.addKitItem(item);
		}
		
		
				return "redirect:/user/show-list";
	}
	
	@RequestMapping("/checkout")
	public ModelAndView checkout(Model model) {
		List<KitDetail> kd = kitDetailService.getAllKitItemsOfAKit();
		CoronaKit ck=new CoronaKit();
		
		int sno=1;
		int total = 0;
		for(int i =0; i<kd.size();i++)
		{
			
			total = total + kd.get(i).getAmount();
			System.out.println("TOTAL---"+total);
		}
		
		ck.setTotalAmount(total);
		
		ck.setId(sno);
		
		coronaKitService.saveKit(ck);
		CoronaKit id = coronaKitService.getKitById(sno);
		
		return new ModelAndView("checkout-address","coronaKit",coronaKitService.getKitById(sno));
		
		
	}
	
	@RequestMapping("/finalize")
	public String finalizeOrder(@RequestParam(value = "address") String address, @RequestParam(value = "date") String date, Model model) {
		CoronaKit finalck = new CoronaKit();
		int sno=1;
		finalck.setDeliveryAddress(address);
		finalck.setOrderDate(date);
		finalck.setId(sno);
		CoronaKit ck = coronaKitService.getKitById(sno);
		finalck.setTotalAmount(ck.getTotalAmount());
		model.addAttribute("ck",finalck);
		List<KitDetail> kdlist = kitDetailService.getAllKitItemsOfAKit();
		model.addAttribute("kitdetail", kdlist);
		return "show-summary";
	}
	
	@RequestMapping("/delete")
	public ModelAndView deleteItem(@RequestParam("id") int id) {
		kitDetailService.deleteProduct(id);
		return new ModelAndView("show-cart","cart",kitDetailService.getAllKitItemsOfAKit());
	}
}
