package com.eval.coronakit.service;

import java.util.List;

import com.eval.coronakit.entity.KitDetail;
import com.eval.coronakit.entity.ProductMaster;

public interface KitDetailService {
	public KitDetail addKitItem(KitDetail kitItem);
	public KitDetail getKitItemById(int itemId);
	public List<KitDetail> getAllKitItemsOfAKit();
	public KitDetail deleteProduct(int id);
	
}
