package com.eval.coronakit.controller;




import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.eval.coronakit.entity.ProductMaster;
import com.eval.coronakit.service.ProductService;






@Controller
@RequestMapping("/admin")
public class AdminController {

	
	@Autowired
	ProductService productService;
	
	
	@GetMapping("/home")
	public String home() {
		return "admin-home";
	}
	
	@GetMapping("/product-entry")
	public ModelAndView productEntry() {
		ModelAndView mv = new ModelAndView("add-new-item","product",new ProductMaster());
		mv.addObject("isNew",true);				
		return mv;
	}
	
	@PostMapping("/product-save")
	public ModelAndView productSave(@ModelAttribute("product") @Valid ProductMaster product,BindingResult result)  {
		ModelAndView mv=null;
		
		/**if(result.hasErrors()) {
			mv =new ModelAndView("itemFormPage","item",item);
			mv.addObject("isNew",true);
		}else {}**/
			productService.addNewProduct(product);
			mv = new ModelAndView("show-all-item-admin","product",productService.getAllProducts());
		
		
		return mv;
	}

	@GetMapping("/product-list")
	public ModelAndView productList() {
		return new ModelAndView("show-all-item-admin","product",productService.getAllProducts());
	}
	
	@GetMapping("/product-delete")
	public ModelAndView doDelteItem(@RequestParam("id") int productId)  {
		productService.deleteProduct(productId);
		return new ModelAndView("show-all-item-admin","product",productService.getAllProducts());
				
	}
	
}
